<?php

class BusXL {

    private $type;
    private $plateNumber;
    function __construct($type, $plateNumber) {
        $this->type = $type;
        $this->plateNumber = $plateNumber;
    }


}
